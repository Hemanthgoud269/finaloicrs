package com.dao;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.Claimbean;
import com.controller.Commonconnection;

public class Createclaim extends HttpServlet {
Connection c;
	Statement stmt=null;
	ResultSet rs=null,rs1=null,rs2=null;
	PreparedStatement ps=null,ps1=null,ps2=null;
	String str=null;
	RequestDispatcher rd=null;
	Claimbean cbean=new Claimbean();
	ClaimDao obj1=new ClaimDao();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			System.out.println("wukgfyudsg");
			 c=Commonconnection.getCon();
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String s2=null;
		String st1=request.getParameter("reason");
		String st2=request.getParameter("location");
		String st3=request.getParameter("city");
		String st4=request.getParameter("state");
		String st5=request.getParameter("zip");
         int zi=Integer.parseInt(st5);
         System.out.println(zi);
        String st6=request.getParameter("claimtype");
        cbean.setCreason(st1);
       cbean.setAlocation(st2);
        cbean.setAcity(st3);
        cbean.setAstate(st4);
        cbean.setZip(zi);
        cbean.setCtype(st6);
        
        String sq1="select claimnumber_seq.nextval from dual";
        stmt=c.createStatement();
      
       rs=stmt.executeQuery(sq1);
       int a=0;
       int cn=0;
       while(rs.next())
       {
       	cn=rs.getInt(1);
       } 
       
       String sq2="select policynumber_seq.nextval from dual";
       stmt=c.createStatement();
     
      rs1=stmt.executeQuery(sq2);
      int b=0;
      int pn=0;
      while(rs1.next())
      {
      	pn=rs1.getInt(1);
      } 
        ps=c.prepareStatement(QueryMapper.INSERT_QUERY);
        //String sql="insert into claim values(claimnumber_seq.nextval,?,?,?,?,?,?,policynumber_seq.nextval)";
      ps.setInt(1, cn);
        ps.setString(2, cbean.getCreason());
        ps.setString(3, cbean.getAlocation());
        ps.setString(4, cbean.getAcity());
        ps.setString(5, cbean.getAstate());
        ps.setInt(6, cbean.getZip());
        ps.setString(7, cbean.getCtype());
        ps.setInt(8,pn);
        
    ps.executeUpdate();
    HttpSession session2=request.getSession(false);
	String s=(String)session2.getAttribute("user");
    ps2=c.prepareStatement("select rolecode from userrole where username=?");
    ps2.setString(1, s);
    rs2=ps2.executeQuery();
    
    while(rs2.next()) {
    	 s2=rs2.getString(1);
    }
    if("Insured".equals(s2))
    {
    	 String sql="insert into viewclaim values('"+s+"',"+pn+",'"+cbean.getCtype()+"',"+cn+")";
    	    ps1=c.prepareStatement(sql);
    	    ps1.executeUpdate();
    	    HttpSession session =request.getSession();
    	    session.setAttribute("claim",cn);
    	   
    }
    else {
    	HttpSession session14=request.getSession(false);
        
        String str=(String)session14.getAttribute("un");
        String sql="insert into viewclaim values('"+str+"',"+pn+",'"+cbean.getCtype()+"',"+cn+")";
       
        
    ps1=c.prepareStatement(sql);
    ps1.executeUpdate();
    HttpSession session =request.getSession(true);
    session.setAttribute("claim",cn);
   
    }
    obj1.doGet(request, response);
		}
		catch(Exception e)
		{
			System.out.println(e);
			
		}
		}
}
