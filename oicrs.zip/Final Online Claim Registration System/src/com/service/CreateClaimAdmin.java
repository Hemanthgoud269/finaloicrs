package com.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.controller.Commonconnection;

public class CreateClaimAdmin extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
			RequestDispatcher rd=null;
		ResultSet rs2=null;
	   String st=request.getParameter("un");
	   HttpSession session14=request.getSession(true);
		session14.setAttribute("un",st );		
	   rd=request.getRequestDispatcher("/claimcreate.jsp");
				
				rd.forward(request, response);
				}
			   
		} 
